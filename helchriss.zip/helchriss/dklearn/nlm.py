import torch
import torch.nn as nn

class LogicDeductionLayer(nn.Module):
    def __init__(self, hidden_dim = 128):
        super().__init__()
    
    def forward(self, x):
        return x

class NeuroLogicMachine(nn.Module):
    def __init__(self,):
        super().__init__()
    
    def forward(self,x):
        return x