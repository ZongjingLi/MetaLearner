
class BinaryTree:
    def __init__(self, data):
        self.data = data
    
class SegmentTree:
    def __init__(self, data):
        self.data = data

class BalanceTree:
    def __init__(self, data):
        self.data = data