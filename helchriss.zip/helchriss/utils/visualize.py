import numpy as np

def visualize_pointclouds():
    return 

def visualize_image_batch():
    # [B,W,H,C]
    return 